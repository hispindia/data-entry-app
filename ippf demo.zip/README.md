# data-entry-app
List of all custom apps for data entry purpose.
